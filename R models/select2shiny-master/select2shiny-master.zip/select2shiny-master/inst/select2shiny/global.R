sel_choices <- expand.grid(LETTERS,letters)
sel_choices <- paste(sel_choices[,1],sel_choices[,2], sep="-")