## Getting select2 to work with Shiny

- [select2](http://ivaynberg.github.com/select2/)
- [Shiny](http://www.rstudio.com/shiny/) by [Rstudio](http://www.rstudio.com/). 
